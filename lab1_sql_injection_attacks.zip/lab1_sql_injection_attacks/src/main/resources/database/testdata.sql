INSERT INTO user_data (username, password) VALUES
('user1', 'pass123'),
('user2', 'pass456'),
('user3', 'pass789'),
('john_doe', 'password123'),
('jane_smith', 'password456'),
('bob_wilson', 'password789'),
('alice_jones', 'pass321'),
('sam_brown', 'pass654'),
('emma_davis', 'pass987'),
('mike_taylor', 'userpass123');
